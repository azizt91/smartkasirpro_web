<table>
    <thead>
        <tr>
            <th colspan="8" style="font-weight: bold; font-size: 14px; text-align: center;">LAPORAN PENJUALAN</th>
        </tr>
        <tr>
            <th colspan="8" style="text-align: center;">Periode: <?php echo e($startDate); ?> - <?php echo e($endDate); ?></th>
        </tr>
        <tr></tr>
        <tr>
            <td colspan="2" style="font-weight: bold;">RINGKASAN</td>
        </tr>
        <tr>
            <td colspan="2">Total Penjualan</td>
            <td style="font-weight: bold;">Rp <?php echo e(number_format($summary['total_amount'], 0, ',', '.')); ?></td>
        </tr>
        <tr>
            <td colspan="2" style="font-style: italic; padding-left: 10px;"> - Tunai / Transfer</td>
            <td style="font-style: italic;">Rp <?php echo e(number_format($summary['total_received'], 0, ',', '.')); ?></td>
        </tr>
        <tr>
            <td colspan="2" style="font-style: italic; padding-left: 10px;"> - Piutang</td>
            <td style="font-style: italic;">Rp <?php echo e(number_format($summary['total_receivables'], 0, ',', '.')); ?></td>
        </tr>
        <tr>
            <td colspan="2">Total Pengeluaran</td>
            <td style="color: red;">(Rp <?php echo e(number_format($summary['total_expenses'], 0, ',', '.')); ?>)</td>
        </tr>
        <tr>
            <td colspan="2">Total Pembelian Stok</td>
            <td style="color: orange;">(Rp <?php echo e(number_format($summary['total_purchases'], 0, ',', '.')); ?>)</td>
        </tr>
        <tr>
            <td colspan="2" style="font-weight: bold;">LABA BERSIH</td>
            <td style="font-weight: bold; color: <?php echo e($summary['net_income'] >= 0 ? 'green' : 'red'); ?>;">Rp <?php echo e(number_format($summary['net_income'], 0, ',', '.')); ?></td>
        </tr>
        <tr></tr>
        <tr>
            <th style="font-weight: bold; border: 1px solid #000000;">Kode Transaksi</th>
            <th style="font-weight: bold; border: 1px solid #000000;">Tanggal</th>
            <th style="font-weight: bold; border: 1px solid #000000;">Kasir</th>
            <th style="font-weight: bold; border: 1px solid #000000;">Metode Pembayaran</th>
            <th style="font-weight: bold; border: 1px solid #000000;">Subtotal</th>
            <th style="font-weight: bold; border: 1px solid #000000;">Diskon</th>
            <th style="font-weight: bold; border: 1px solid #000000;">Pajak</th>
            <th style="font-weight: bold; border: 1px solid #000000;">Total</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="border: 1px solid #000000;"><?php echo e($transaction->transaction_code); ?></td>
                <td style="border: 1px solid #000000;"><?php echo e($transaction->created_at->format('d/m/Y H:i')); ?></td>
                <td style="border: 1px solid #000000;"><?php echo e($transaction->user->name); ?></td>
                <td style="border: 1px solid #000000;"><?php echo e(ucfirst($transaction->payment_method)); ?></td>
                <td style="border: 1px solid #000000;"><?php echo e($transaction->subtotal); ?></td>
                <td style="border: 1px solid #000000;"><?php echo e($transaction->discount); ?></td>
                <td style="border: 1px solid #000000;"><?php echo e($transaction->tax); ?></td>
                <td style="border: 1px solid #000000;"><?php echo e($transaction->total_amount); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<table>
    <tr></tr>
    <tr>
        <td colspan="4" style="font-weight: bold; font-size: 12px;">RINCIAN PENGELUARAN OPERASIONAL</td>
    </tr>
    <tr>
        <th style="font-weight: bold; border: 1px solid #000000;">Tanggal</th>
        <th style="font-weight: bold; border: 1px solid #000000;">Keterangan</th>
        <th style="font-weight: bold; border: 1px solid #000000;">Dicatat Oleh</th>
        <th style="font-weight: bold; border: 1px solid #000000;">Jumlah</th>
    </tr>
    <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="border: 1px solid #000000;"><?php echo e(\Carbon\Carbon::parse($expense->date)->isoFormat('D MMM YYYY')); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($expense->description); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($expense->user->name ?? '-'); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($expense->amount); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td colspan="3" style="font-weight: bold; border: 1px solid #000000;">TOTAL PENGELUARAN</td>
        <td style="font-weight: bold; border: 1px solid #000000;"><?php echo e($summary['total_expenses']); ?></td>
    </tr>
</table>

<table>
    <tr></tr>
    <tr>
        <td colspan="6" style="font-weight: bold; font-size: 12px;">RINCIAN PEMBELIAN STOK</td>
    </tr>
    <tr>
    <tr>
        <th style="font-weight: bold; border: 1px solid #000000;">Tanggal</th>
        <th style="font-weight: bold; border: 1px solid #000000;">Produk</th>
        <th style="font-weight: bold; border: 1px solid #000000;">Qty</th>
        <th style="font-weight: bold; border: 1px solid #000000;">Supplier</th>
        <th style="font-weight: bold; border: 1px solid #000000;">Catatan</th>
        <th style="font-weight: bold; border: 1px solid #000000;">Total</th>
    </tr>
    <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="border: 1px solid #000000;"><?php echo e(\Carbon\Carbon::parse($purchase->date)->isoFormat('D MMM YYYY')); ?></td>
            <td style="border: 1px solid #000000;">
                <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($item->product->name ?? 'Produk Dihapus'); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td style="border: 1px solid #000000;">
                <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($item->quantity); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td style="border: 1px solid #000000;"><?php echo e($purchase->supplier->name ?? 'Umum'); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($purchase->note ?? '-'); ?></td>
            <td style="border: 1px solid #000000;"><?php echo e($purchase->total_amount); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td colspan="5" style="font-weight: bold; border: 1px solid #000000;">TOTAL PEMBELIAN STOK</td>
        <td style="font-weight: bold; border: 1px solid #000000;"><?php echo e($summary['total_purchases']); ?></td>
    </tr>
</table>
<?php /**PATH C:\xampp\htdocs\kasir-app\resources\views/reports/sales-excel.blade.php ENDPATH**/ ?>